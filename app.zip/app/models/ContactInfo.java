package models;

import java.util.Date;
import java.util.List;

import play.libs.Time;


public class ContactInfo 
{
	public String address;
	public String phone;
	public int zipcode;
	public String email;
	
}
