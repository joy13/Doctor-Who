package models;

import java.util.List;


//ViewModels

public class HomeViewModel
{
	//List of Symptoms
	public List<String> symptoms;
	//Patient info
	//public Patient patient;
	
}