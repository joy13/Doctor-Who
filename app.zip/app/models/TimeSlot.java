package models;

import java.util.Date;
import java.util.List;

import play.libs.Time;


public class TimeSlot
{
	public String Period;
	public Boolean isAvailable;
}
