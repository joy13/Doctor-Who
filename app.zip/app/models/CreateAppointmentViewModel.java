package models;

public class CreateAppointmentViewModel
{
	public Disease disease;
	public Patient patient;
}