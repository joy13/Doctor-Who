package models;

import java.util.Date;
import java.util.List;

import play.data.format.Formats.DateTime;
import play.libs.Time;


public class Patient
{
	public int age;
	public String ethnicity;
	public String lifestyle;
	public int zipcode;
}

